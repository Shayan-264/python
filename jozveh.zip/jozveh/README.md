# python learning

Note: Using these notebooks is not enough to learn Python and it is necessary to watch the videos presented on the Sabzlearn website.
