def my_add (n1,n2):
    return n1+n2

def my_multiply(n1,n2):
    return n1*n2

def my_style(weight, age, size):
    ""
    
result=my_add(5, 10)

my_style(weight, age, size)